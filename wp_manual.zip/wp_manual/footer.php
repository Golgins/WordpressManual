<footer class="paticka">
    <hr class="cara2">
    <div class="row d-flex align-items-center">
        <div class="col-4">
            <p> &copy; 2025 Adam Ruml</p>
        </div>
        <div class="col-2 mx-auto d-flex justify-content-center">
            <img src="<?php bloginfo('template_url');?>/img/logo.png" style="width: 50px; height: 50px;" class="rounded-pill">
        </div>
        <div class="col-4 d-flex justify-content-end">
            <p> Wordpress Manuál </p>
        </div>
    </div>
</footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/js/bootstrap.bundle.min.js" integrity="sha384-j1CDi7MgGQ12Z7Qab0qlWQ/Qqz24Gc6BM0thvEMVjHnfYGF0rmFCozFSxQBxwHKO" crossorigin="anonymous"></script>

</body>
</html>